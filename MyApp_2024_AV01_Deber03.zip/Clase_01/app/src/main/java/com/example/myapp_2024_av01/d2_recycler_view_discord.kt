package com.example.myapp_2024_av01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView

class d2_recycler_view_discord : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_d2_recycler_view_discord)

        //Lamada a los botones notificacion y profile
        //Encontrar una vista (boton) por su id
        val botonNotificacion = findViewById<ImageView>(R.id.img_note_d2)
        //Añadir un listener al boton
        botonNotificacion.
            //Iniciar una actividad al pulsar el boton
        setOnClickListener {
            irActividad(d2_recycler_view_notificacion::class.java)
        }

        //Encontrar una vista (boton) por su id
        val BotonProfile = findViewById<ImageView>(R.id.img_profile_d2)
        //Añadir un listener al boton
        BotonProfile.
            //Iniciar una actividad al pulsar el boton
        setOnClickListener {
            irActividad(d2_recycler_view_profile::class.java)
        }


    }





    fun irActividad(
        clase: Class<*>
    ){
        val intent = Intent(this, clase);
        startActivity(intent)
    }
}