package com.example.myapp_2024_av01

class d2_BD_notificacion {

    companion object{
        val arregloNotificacion = arrayListOf<d2_Notificacion>()

        //Datos en memoria
        init {
            arregloNotificacion
                .add(
                    d2_Notificacion("Jose2007", "menciono", "Servidor de Juegos", "Vengan a jugar")
                )

            arregloNotificacion
                .add(
                    d2_Notificacion("Sniper99", "menciono", "Grupo de Trabajo", "mañana es la entrega")
                )

            arregloNotificacion
                .add(
                    d2_Notificacion("Cam0123", "etiqueto", "SalidaAmigos", "5 por cabeza")
                )
        }
    }


}