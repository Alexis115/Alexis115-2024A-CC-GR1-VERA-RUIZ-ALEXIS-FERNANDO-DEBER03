package com.example.myapp_2024_av01

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.snackbar.Snackbar

class d3_isla : AppCompatActivity() {

    val arreglo = d3_BD_islas.arregloBIsla

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_d3_isla)
        val listView = findViewById<ListView>(R.id.lv_islas_d3)
        val adaptador = ArrayAdapter(
            this, //contexto
            android.R.layout.simple_list_item_1, //lauout xml a usar
            arreglo
        )
        listView.adapter = adaptador
        //Refresca la interfaz al añadir, actualizar o eliminar registros
        //debe ser llamado para evitar estar refrecando a cada rato y consumiendo recursos
        adaptador.notifyDataSetChanged()

        //añadir la funcion para escuchar el boton de añadir listview
        val botonAñadirListView = findViewById<Button>(
            R.id.btn_crearIsla_d3
        )
        botonAñadirListView.setOnClickListener {
            añadirIsla(adaptador)
        }
        registerForContextMenu(listView) // NUEVA LINEA
    }

    fun añadirIsla(adaptador: ArrayAdapter<d3_BIsla>) {
        arreglo.add(
            d3_BIsla(4, "Caerleon")
        )
        adaptador.notifyDataSetChanged()

    }

    fun mostrarSnackbar(texto: String) {
        val snack = Snackbar.make(
            findViewById(R.id.cl_islas_d3),
            texto,
            Snackbar.LENGTH_INDEFINITE
        )
        snack.show()
    }

    var posicionItemSeleccionado = -1

    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        //llenamos opciones del menu
        val inflater = menuInflater
        inflater.inflate(R.menu.menu, menu)
        //obtener id
        val info = menuInfo as AdapterView.AdapterContextMenuInfo
        val posicion = info.position
        posicionItemSeleccionado = posicion

    }

    override fun onContextItemSelected(
        item: MenuItem
    ): Boolean {
        return when (item.itemId) {
            R.id.mi_editar -> {
                mostrarSnackbar("Editar isla")
                abrirDialogoEditar()
                return true
            }

            R.id.mi_eliminar -> {
                mostrarSnackbar("Eliminar isla")
                abrirDialogoEliminar()
                return true
            }

            R.id.mi_ver -> {
                irActividad(d3_cultivo::class.java)
                return true
            }

            else -> super.onContextItemSelected(item)
        }
    }

    fun irActividad(
        clase: Class<*>
    ){
        val intent = Intent(this, clase);
        startActivity(intent)
    }

    fun abrirDialogoEditar(){
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Editar Isla")
        builder.setPositiveButton(
            "Aceptar",
            DialogInterface.OnClickListener{
                    dialogInterface, i ->
                mostrarSnackbar("Editar Aceptado")
            }
        )
        builder.setNegativeButton("Cancelar", null)
        val opciones = resources.getStringArray(
            R.array.stringn_array_opciones_editar
        )
        val seleccionPrevia = booleanArrayOf(
            true, false
        )
        builder.setMultiChoiceItems(
            opciones, seleccionPrevia,
            {
                    dialog, which, isChecked->
                mostrarSnackbar("Dio click en el item $which")
            }
        )
        val dialogo = builder.create()
        dialogo.show()
    }

    fun abrirDialogoEliminar(){
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Eliminar isla")
        builder.setPositiveButton(
            "Aceptar",
            DialogInterface.OnClickListener{
                    dialogInterface, i ->
                mostrarSnackbar("Eliminar Aceptado")
            }
        )
        builder.setNegativeButton("Cancelar", null)
        val opciones = resources.getStringArray(
            R.array.stringn_array_opciones_eliminar
        )
        val seleccionPrevia = booleanArrayOf(
            true, false, false
        )
        builder.setMultiChoiceItems(
            opciones, seleccionPrevia,
            {
                    dialog, which, isChecked->
                mostrarSnackbar("Dio click en el item $which")
            }
        )
        val dialogo = builder.create()
        dialogo.show()
    }

}