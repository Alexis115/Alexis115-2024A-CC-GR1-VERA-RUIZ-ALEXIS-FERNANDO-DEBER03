package com.example.myapp_2024_av01

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class d2_Adaptador_Notificacion(
    private val contexto: d2_recycler_view_notificacion,
    private val lista: ArrayList<d2_Notificacion>,
    private val recyclerView: RecyclerView
) : RecyclerView.Adapter<
        d2_Adaptador_Notificacion.MyViewHolder
        >() {

    //Obtenemos los siguientes diferentes componenetes visuales
    inner class MyViewHolder(
        view: View
    ): RecyclerView.ViewHolder(view){
        //Obtenemos los siguientes diferentes componenetes visuales
        val nombreTextView: TextView
        val accionTextView: TextView
        val lugarTextView: TextView
        val mensajeTextView: TextView

        init {
            nombreTextView = view.findViewById(R.id.tv_username_d2)
            accionTextView = view.findViewById(R.id.tv_accion_d2)
            lugarTextView = view.findViewById(R.id.tv_lugar_d2)
            mensajeTextView = view.findViewById(R.id.pt_mensaje_d2)
        }



    }

    //Stetear el layout que vamos a utilizar
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.d2_recycler_view_notificacion, parent, false)
        return MyViewHolder(itemView)

    }

    override fun getItemCount(): Int {
        return this.lista.size
    }

    //Setear los datos para la iteracion
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val notificacionActual = this.lista[position]
        holder.nombreTextView.text = notificacionActual.nombre
        holder.accionTextView.text = notificacionActual.accion
        holder.lugarTextView.text = notificacionActual.lugar
        holder.mensajeTextView.text = notificacionActual.mensaje

    }
}