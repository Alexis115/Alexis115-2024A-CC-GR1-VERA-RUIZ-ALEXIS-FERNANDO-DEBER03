package com.example.myapp_2024_av01

import android.os.Parcel
import android.os.Parcelable

class d3_BCultivo (
    var id:Int,
    var nombre:String?,
    var semilla:Int,

): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString(),
        parcel.readInt()
    ) {
    }

    override fun toString(): String {
        return "$nombre $semilla"
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(nombre)
        parcel.writeInt(semilla)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<d3_BCultivo> {
        override fun createFromParcel(parcel: Parcel): d3_BCultivo {
            return d3_BCultivo(parcel)
        }

        override fun newArray(size: Int): Array<d3_BCultivo?> {
            return arrayOfNulls(size)
        }
    }

}