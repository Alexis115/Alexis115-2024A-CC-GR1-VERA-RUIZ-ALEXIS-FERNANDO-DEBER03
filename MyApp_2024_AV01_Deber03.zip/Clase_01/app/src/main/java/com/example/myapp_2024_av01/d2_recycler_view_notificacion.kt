package com.example.myapp_2024_av01

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView

class d2_recycler_view_notificacion : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_d2_recycler_view_notificacion)

        //Lamada a los botones notificacion y profile
        //Encontrar una vista (boton) por su id
        val botonNotificacion = findViewById<ImageView>(R.id.img_note_nt_d2)
        //Añadir un listener al boton
        botonNotificacion.
            //Iniciar una actividad al pulsar el boton
        setOnClickListener {
            irActividad(d2_recycler_view_notificacion::class.java)
        }

        //Encontrar una vista (boton) por su id
        val BotonProfile = findViewById<ImageView>(R.id.img_profile_nt_d2)
        //Añadir un listener al boton
        BotonProfile.
            //Iniciar una actividad al pulsar el boton
        setOnClickListener {
            irActividad(d2_recycler_view_profile::class.java)
        }

        inicializarRecyclerVewNotificacion()

    }

    fun inicializarRecyclerVewNotificacion(){
        val recyclerView = findViewById<RecyclerView>(R.id.rv_notificacion_d2)

        //Creacion del adaptador
        val adaptador = d2_Adaptador_Notificacion(
            this,
            d2_BD_notificacion.arregloNotificacion,
            recyclerView
        )
        recyclerView.adapter = adaptador
        recyclerView.itemAnimator = androidx.recyclerview.widget.DefaultItemAnimator()
        recyclerView.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
        //Modificar el numero de elementos del array
        adaptador.notifyDataSetChanged()
    }




    fun irActividad(
        clase: Class<*>
    ){
        val intent = Intent(this, clase);
        startActivity(intent)
    }
}