package com.example.myapp_2024_av01

import android.os.Parcel
import android.os.Parcelable

class d2_Notificacion(
    var nombre:String?,
    var accion:String?,
    var lugar:String?,
    var mensaje:String?

): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString()
    ) {
    }

    override fun toString(): String {
        return "$nombre $accion $lugar ${mensaje}"
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(nombre)
        parcel.writeString(accion)
        parcel.writeString(lugar)
        parcel.writeString(mensaje)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<d2_Notificacion> {
        override fun createFromParcel(parcel: Parcel): d2_Notificacion {
            return d2_Notificacion(parcel)
        }

        override fun newArray(size: Int): Array<d2_Notificacion?> {
            return arrayOfNulls(size)
        }
    }

}